$('#staffNeedRange').rangeSlider({
    //settings: true,

    scale: true
}, {
    step: 1,
    values: [20],
    min: 0,
    max: 100
});

$('#staffPresentRange').rangeSlider({
    //    settings: true,
    scale: true
}, {
    step: 1,
    values: [25],
    min: 0,
    max: 100
});


var typeofasset = document.getElementById('typeasset');
var numassets = document.getElementById('numOfassets');
var costperasset = document.getElementById('costofasset');
var Shiftsperday = document.getElementById('ShiftsPerday');
var numberofusers = document.getElementById('NumberofUsers');
var yearlysalaryperuser = document.getElementById('YearlySalaryPerUser');
var firstSlider = document.querySelector("#staffNeedRange .slider__tip");
var secondSlider = document.querySelector("#staffPresentRange .slider__tip");

/* hourly rate calculator */
var actualcostofemploy = 1.17
var hoursworked = 1730
var hourlyrate


/* roi achieved in calculator */
var systemcostasset = 500
var totalsystemcost;

var monthstillrecovery;
var monthlyongoingsaving;


/* Number of lost assets */
var Numberoflostassets;
var Totalyearlysavingloss;


/* asset damage */
var costofrepair = 300
var numberofdamagesasset;
var Currentcostofdamages;
var Totalyearlysaving;
var seventypercentdamage = 0.7;



/* asset collection and return */
var Timesavingperasset = 4;


/* asset Collection and return - Staff on shift */
var savingpershift;
var Savingperweek;
var Savingperyear; //in euros
var savingperhours; //in hours
var Savingperyeartotal;

/* asset Collection and return - asset admin */
var Timesavingassetadmin = 0.5;
var savingpershiftadmin;
var Savingperweekadmin;
var Savingperyearadmin; //in euros
var savingperhoursadmin; //in hours
var Savingperyearadmintotal;

/* headlines */
var totalannualsaving;
var TotalHoursSavedperYear;
var Monthlyongoingsaving;
var Savingaftermonths;



function validateform () {



    var i = 0;
    if (typeofasset.value == "") {
        document.getElementById('selecterror').innerHTML = "please select";
    } else {
        i++;
        document.getElementById('selecterror').innerHTML = "";

    }
    if (numassets.value == "") {
        document.getElementById('assetfield').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('assetfield').innerHTML = "";
    }
    if (costperasset.value == "") {
        document.getElementById('costofasset').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('costofasset').innerHTML = "";
    }
    if (Shiftsperday.value == "") {
        document.getElementById('shiftselecterror').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('shiftselecterror').innerHTML = "";
    }
    if (numberofusers.value == "") {
        document.getElementById('usersfield').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('usersfield').innerHTML = "";
    }
    if (yearlysalaryperuser.value == "") {
        document.getElementById('yearlysalary').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('yearlysalary').innerHTML = "";
    }
    if (firstSlider.getAttribute("data-value") == 0) {
        document.getElementById('assetlosserror').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('assetlosserror').innerHTML = "";
    }
    if (secondSlider.getAttribute("data-value") == 0) {
        document.getElementById('damageerror').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('damageerror').innerHTML = "";
    }

    if (i == 8) {
        console.log(`Type of Asset = ${typeofasset.value} \nNumber of Assets = ${numassets.value} \nCost Per Asset = ${costperasset.value} \nShifts Per day = ${(Shiftsperday.value)} \nNumber of Users = ${numberofusers.value} \nYearly Salary Per User = ${yearlysalaryperuser.value} \nfirst slider value = ${parseInt(firstSlider.getAttribute("data-value"))} \nsecond slider value = ${parseInt(secondSlider.getAttribute("data-value"))}`);
        hourlyratecalculator();
        AssetLoss();
        assetdamage();
        Staffmemberhourly();
        allstaffshift();
        staffshiftadmin();
        headlines();
        roiachievedcalculator();

    }
}


function hourlyratecalculator () {

    var costofemploy = yearlysalaryperuser.value * actualcostofemploy;
    hourlyrate = costofemploy / hoursworked;

    console.log(`Yearly salary = ${yearlysalaryperuser.value} \nActual cost of employee  = ${costofemploy} \nHours worked per year = ${hoursworked} \nHourly Rate = ${hourlyrate}`);
}


function roiachievedcalculator () {

    totalsystemcost = numassets.value * systemcostasset;
    monthstillrecovery = totalannualsaving / totalsystemcost;
    monthlyongoingsaving = (totalannualsaving / 12) - (totalsystemcost / 36);

    console.log(`system cost per asset = ${systemcostasset} \ntotal system cost = ${totalsystemcost} \nTotal customer cost per year = ${totalannualsaving} \nMonths till recovery = ${monthstillrecovery} \nMonthly ongoing saving = ${monthlyongoingsaving}`);

}


function AssetLoss () {

    Numberoflostassets = numassets.value * parseInt(firstSlider.getAttribute("data-value")) / 100;
    Totalyearlysavingloss = costperasset.value * Numberoflostassets;

    console.log(`Number of assets = ${numassets.value} \ncost per asset = ${costperasset.value} \nfirst slider value = ${parseInt(firstSlider.getAttribute("data-value"))} \nNumber of lost assets = ${Numberoflostassets} \nTotal yearly saving = ${Totalyearlysavingloss}`)
}


function assetdamage () {

    numberofdamagesasset = numassets.value * parseInt(secondSlider.getAttribute("data-value")) / 100;
    Currentcostofdamages = costofrepair * parseInt(secondSlider.getAttribute("data-value"));
    Totalyearlysaving = Currentcostofdamages * seventypercentdamage;


    console.log(`Number of assets = ${numassets.value} \nCost of repair = ${costofrepair} \nPercentage of damaged = ${parseInt(secondSlider.getAttribute("data-value"))} \nNumber of damaged assets = ${numberofdamagesasset} \nCurrent cost of damages = ${Currentcostofdamages} \nTotal yearly saving = ${Totalyearlysaving}`);

}

function Staffmemberhourly () {

    console.log(`Staff member hourly rate = ${hourlyrate} \nTime saving per asset = ${Timesavingperasset}`);

}


function allstaffshift () {


    savingpershift = numassets.value * (hourlyrate * (Timesavingperasset / 60));
    Savingperweek = savingpershift * 7;
    Savingperyear = Savingperweek * 52;
    savingperhours = Savingperyear / hourlyrate;

    if (Shiftsperday.value == "1") {
        console.log(`Type of Asset = ${typeofasset.value} \nSaving per shift = ${Math.trunc(savingpershift)} \nSaving per week = ${Math.trunc(Savingperweek)} \nSaving per week  = ${Math.trunc(Savingperyear)} \nsaving per hours = ${Math.trunc(savingperhours)}`)
    }
    if (Shiftsperday.value == "2") {
        savingpershift = savingpershift * 2;
        Savingperweek = savingpershift * 7;
        Savingperyear = Savingperweek * 52;
        savingperhours = Savingperyear / hourlyrate;

        console.log(`Type of Asset = ${typeofasset.value} \nsaving per shift = ${Math.trunc(savingpershift)} \nsaving per week = ${Math.trunc(Savingperweek)} \nSaving per year =${Math.trunc(Savingperyear)} \nsaving per hours = ${Math.trunc(savingperhours)}`);

    }
    if (Shiftsperday.value == "3") {
        savingpershift = savingpershift * 3;
        Savingperweek = savingpershift * 7;
        Savingperyear = Savingperweek * 52;
        savingperhours = Savingperyear / hourlyrate;

        console.log(`Type of Asset = ${typeofasset.value} \nsaving per shift = ${Math.trunc(savingpershift)} \nsaving per week = ${Math.trunc(Savingperweek)} \nSaving per year total =${Math.trunc(Savingperyeartotal)} \nsaving per hours = ${Math.trunc(savingperhours)}`);
    }

}


function staffshiftadmin () {
    savingpershiftadmin = numassets.value * (hourlyrate * (Timesavingassetadmin / 60));
    Savingperweekadmin = savingpershiftadmin * 7;
    Savingperyearadmin = Savingperweekadmin * 52;
    savingperhoursadmin = Savingperyearadmin / hourlyrate;

    if (Shiftsperday.value == "1") {
        console.log(`Type of Asset = ${typeofasset.value} \nsaving per shift admin = ${Math.trunc(savingpershiftadmin)} \nSaving per week admin = ${Math.trunc(Savingperweekadmin)} \nSaving per year admin = ${Math.trunc(Savingperyearadmin)} \n saving per hours admin = ${Math.trunc(savingperhoursadmin)}`);
    }
    if (Shiftsperday.value == "2") {
        savingpershiftadmin = savingpershiftadmin * 2;
        Savingperweekadmin = savingpershiftadmin * 7;
        Savingperyearadmin = Savingperweekadmin * 52;
        savingperhoursadmin = Savingperyearadmin / hourlyrate;

        console.log(`Type of Asset = ${typeofasset.value} \nsaving per shift = ${Math.trunc(savingpershiftadmin)} \nsaving per week = ${Math.trunc(Savingperweekadmin)} \nSaving per year =${Math.trunc(Savingperyearadmin)} \nsaving per hours = ${Math.trunc(savingperhoursadmin)}`);
    }
    if (Shiftsperday.value == "3") {
        savingpershiftadmin = savingpershiftadmin * 3;
        Savingperweekadmin = savingpershiftadmin * 7;
        Savingperyearadmintotal = Savingperweekadmin * 52;
        savingperhoursadmin = Savingperyearadmintotal / hourlyrate;

        console.log(`Type of Asset = ${typeofasset.value} \nsaving per shift = ${Math.trunc(savingpershiftadmin)} \nsaving per week = ${Math.trunc(Savingperweekadmin)} \nSaving per year total =${Math.trunc(Savingperyearadmintotal)} \nsaving per hours = ${Math.trunc(savingperhoursadmin)}`);
    }

}


function headlines () {

    totalannualsaving = Savingperyearadmintotal + Savingperyeartotal + Totalyearlysaving + Totalyearlysavingloss;
    TotalHoursSavedperYear = savingperhoursadmin + savingperhours;
    Monthlyongoingsaving = monthlyongoingsaving;
    Savingaftermonths = Monthlyongoingsaving * 36;

    console.log(`total annual saving = ${totalannualsaving} \nTotal Hourss Saved per Year = ${TotalHoursSavedperYear} \n monthly on going saving = ${monthlyongoingsaving} \nSaving after months = ${Savingaftermonths} `)


}















