<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <!-- Font Family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <!-- Fontawesome Icons -->
    <link rel="stylesheet" href="./assets/fontawesome/css/all.css">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Form Submission</title>
</head>

<body>
    <?php
    // Make Connection With Database
    $conn = new mysqli("localhost", "root", "", "techmind_php");

    // Set The Variables And The Values
    if (isset($_POST['insert-data'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = md5($_POST['password']);
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $gender = $_POST['gender'];
        // Make Hobbies In String Form With Implode Function
        $hobbies = $_POST['hobbies'];
        $hobbies1 = implode(',', $hobbies);

        $document = $_FILES["user-file"]["name"];
        $tempname = $_FILES["user-file"]["tmp_name"];
        $folder = "./assets/images/" . $document;
        move_uploaded_file($tempname, $folder);

        $msg = $_POST['msg'];

        // Insert Query
        $insert_data = "INSERT INTO test_table (username, email, password, phone, address, gender, hobbies, document,msg)VALUE('$username', '$email', '$password', '$phone', '$address', '$gender', '$hobbies1', '$document', '$msg')";
        // Check With Condition That The Form Submit Or Not
        if ($conn->query($insert_data) === true) {
            echo "Data Successfully Added !";
            header('location: form-submit-info.php');
        } else {
            echo "Data Not Added !";
        }
    }
    ?>
    <main>
        <section class="form-submit-sec">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-7 col-12 col-xxl-5 mx-auto">
                        <div class="submit-form-class">
                            <form action="" method="post" enctype="multipart/form-data">
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter Your Username">
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="text" class="form-control" id="email" name="email" placeholder="Enter Your Email">
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Your Password">
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Your Phone Number">
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="text" class="form-control" id="address" name="address" placeholder="Enter Your Full Address">
                                    </div>
                                </div>

                                <!-- <div class="row pb-3">
                                    <div class="col">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>Select Your State</option>
                                            <option value="1">First State</option>
                                            <option value="2">Second State</option>
                                            <option value="3">Third State</option>
                                    </div>
                                </div> -->
                                <div class="row pb-3 text-center">
                                    <div class="col">
                                        <input type="radio" name="gender" value="Male" checked>
                                        <label for="gender">Male</label>
                                    </div>
                                    <div class="col">
                                        <input type="radio" name="gender" value="Female">
                                        <label for="gender">Female</label>
                                    </div>
                                    <div class="col">
                                        <input type="radio" name="gender" value="Others">
                                        <label for="gender">Others</label>
                                    </div>
                                </div>
                                <div class="row pb-3 text-center">
                                    <div class="col">
                                        <input type="checkbox" name="hobbies[]" value="Snookers" checked>
                                        <label for="hobbies">Snookers</label>
                                    </div>
                                    <div class="col">
                                        <input type="checkbox" name="hobbies[]" value="Horse Riding" checked>
                                        <label for="hobbies">Horse Riding</label>
                                    </div>
                                    <div class="col">
                                        <input type="checkbox" name="hobbies[]" value="Gaming" checked>
                                        <label for="hobbies">Gaming</label>
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <input type="file" class="form-control" name="user-file">
                                    </div>
                                </div>
                                <div class="row pb-3">
                                    <div class="col">
                                        <textarea name="msg" rows="3" class="form-control" placeholder="Enter Your Message Here ..."></textarea>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col">
                                        <input type="submit" value="Insert Data" name="insert-data" class="btn insert-btn">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

</body>

</html>