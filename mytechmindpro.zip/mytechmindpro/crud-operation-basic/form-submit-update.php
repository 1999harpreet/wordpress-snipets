<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <!-- Font Family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <!-- Fontawesome Icons -->
    <link rel="stylesheet" href="./assets/fontawesome/css/all.css">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Form Submit Update</title>
</head>

<body>
    <?php
    $conn = new mysqli("localhost", "root", "", "techmind_php");
    if (isset($_GET['edit-data'])) {
        $edit_data_id = $_GET['edit-data'];

        // Select Query For Select The Data With ID
        $select_record = "SELECT * FROM test_table WHERE id=$edit_data_id";
        $record = mysqli_query($conn, $select_record);
        if ($record->num_rows > 0) {
            $row = $record->fetch_assoc();

            // Exploade The Hobbies With Explode Function Otherwise The Hobbies Not Display In The Feild
            $hobbies = $row['hobbies'];
            $hobbies1 = explode(',', $hobbies);


            // Update Starts
            if (isset($_POST['update-data'])) {
                $username = $_POST['username'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $phone = $_POST['phone'];
                $address = $_POST['address'];
                $gender = $_POST['gender'];

                $hobbies = $_POST['hobbies'];
                $hobbies2 = implode(',', $hobbies);

                $document = $_FILES["user-file"]["name"];
                $tempname = $_FILES["user-file"]["tmp_name"];
                $folder = "./assets/images/" . $document;
                if (empty($document)) {
                    $document = $row['document'];
                }
                move_uploaded_file($tempname, $folder);
                $msg = $_POST['msg'];

                $update_query = "UPDATE test_table SET username='$username', email='$email', password='$password', phone='$phone', address='$address', gender='$gender', hobbies='$hobbies2', document='$document', msg='$msg' WHERE id=$edit_data_id";
                echo $update_query;
                // die;
                if ($conn->query($update_query) === true) {
                    echo "Data Updated !";
                    header('location: form-submit-info.php');
                } else {
                    echo "Data Is Not Updated !" . $conn->error;
                }
            }
            // Update End
    ?>
            <main>
                <section class="form-update-sec">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-5 col-md-7 col-12 col-xxl-5 mx-auto">
                                <div class="update-form-class">
                                    <form action="" method="post" enctype="multipart/form-data">
                                        <div class="row pb-3">
                                            <div class="col">
                                                <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>">
                                            </div>
                                        </div>
                                        <div class=" row pb-3">
                                            <div class="col">
                                                <input type="text" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">
                                            </div>
                                        </div>
                                        <div class="row pb-3">
                                            <div class="col">
                                                <input type="password" class="form-control" id="password" name="password" value="<?php echo $row['password']; ?>">
                                            </div>
                                        </div>
                                        <div class="row pb-3">
                                            <div class="col">
                                                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo $row['phone']; ?>">
                                            </div>
                                        </div>
                                        <div class="row pb-3">
                                            <div class="col">
                                                <input type="text" class="form-control" id="address" name="address" value="<?php echo $row['address']; ?>">
                                            </div>
                                        </div>

                                        <!-- <div class="row pb-3">
                                    <div class="col">
                                        <select class="form-select" aria-label="Default select example">
                                            <option selected>Select Your State</option>
                                            <option value="1">First State</option>
                                            <option value="2">Second State</option>
                                            <option value="3">Third State</option>
                                    </div>
                                </div> -->
                                        <div class="row pb-3 text-center">
                                            <div class="col">
                                                <input type="radio" name="gender" value="Male" <?php if ($row['gender'] == "Male") { ?> checked <?php } ?>>
                                                <label for="gender">Male</label>
                                            </div>
                                            <div class="col">
                                                <input type="radio" name="gender" value="Female" <?php if ($row['gender'] == "Female") { ?> checked <?php } ?>>
                                                <label for="gender">Female</label>
                                            </div>
                                            <div class="col">
                                                <input type="radio" name="gender" value="Others" <?php if ($row['gender'] == "Others") { ?> checked <?php } ?>>
                                                <label for="gender">Others</label>
                                            </div>
                                        </div>
                                        <div class="row pb-3 text-center">
                                            <div class="col">
                                                <input type="checkbox" name="hobbies[]" value="Snookers" <?php if (in_array("Snookers", $hobbies1)) { ?> checked <?php } ?>>
                                                <label for="hobbies">Snookers</label>
                                            </div>
                                            <div class="col">
                                                <input type="checkbox" name="hobbies[]" value="Horse Riding" <?php if (in_array("Horse Riding", $hobbies1)) { ?> checked <?php } ?>>
                                                <label for=" hobbies">Horse Riding</label>
                                            </div>
                                            <div class="col">
                                                <input type="checkbox" name="hobbies[]" value="Gaming" <?php if (in_array("Gaming", $hobbies1)) { ?> checked <?php } ?>>
                                                <label for="hobbies">Gaming</label>
                                            </div>
                                        </div>
                                        <div class="row pb-3">
                                            <div class="col">
                                                <input type="file" class="form-control" name="user-file">
                                                <span><?php echo $row['document']; ?></span>
                                            </div>
                                        </div>
                                        <div class="row pb-3">
                                            <div class="col">
                                                <textarea name="msg" rows="3" class="form-control"><?php echo $row['msg']; ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col">
                                                <input type="submit" value="Update Data" name="update-data" class="btn update-btn">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </main>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

</body>

</html>
<?php             // header('location: form-submit-update.php');

        } else {
            echo "Data Is Not Selected !";
        }
    }




?>