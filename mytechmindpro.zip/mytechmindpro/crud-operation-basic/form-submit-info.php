<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap Stylesheet -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <!-- Font Family -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300&display=swap" rel="stylesheet">
    <!-- Fontawesome Icons -->
    <link rel="stylesheet" href="./assets/fontawesome/css/all.css">
    <!-- Stylesheet -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Form Submit Information</title>
</head>

<body>
    <?php
    // Make Connection With Database
    $conn = new mysqli("localhost", "root", "", "techmind_php");

    // Select (Fetch) Data From Database For Showing The Data In The Table
    $select_data = "SELECT * FROM test_table";
    // Store The Data In Another Variable To Show The Data Where Your Want Too
    $result = mysqli_query($conn, $select_data);




    // Getting The Data With Id To Delete 
    // sql to delete a record
    if (isset($_GET['delete-data'])) {
        $delete_data_id = $_GET['delete-data'];
        $sql = "DELETE FROM test_table WHERE id=$delete_data_id";

        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
            header('location: form-submit-info.php');
        } else {
            echo "Error deleting record: ";
        }
    }



    ?>
    <main>
        <section class="submit-info-sec">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="submit-table-info">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Username</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Password</th>
                                        <th scope="col">Phone No</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Gender</th>
                                        <th scope="col">Hobbies</th>
                                        <th scope="col">Document</th>
                                        <th scope="col">Message</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    while ($row = $result->fetch_assoc()) {
                                    ?>
                                        <tr>
                                            <td><?php echo $row['id']; ?></td>
                                            <td><?php echo $row['username']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php $security = $row["password"];
                                                echo substr($security, 0, 5); ?></td>
                                            <td><?php echo $row['phone']; ?></td>
                                            <td><?php echo $row['address']; ?></td>
                                            <td><?php echo $row['gender']; ?></td>
                                            <td><?php echo $row['hobbies']; ?></td>
                                            <td><img src="./assets/images/<?php echo $row['document']; ?>" style="width:100px;" alt=""></td>
                                            <td><?php echo $row['msg']; ?></td>

                                            <td><a href="form-submit-update?edit-data=<?php echo $row['id']; ?>"><i class="fas fa-edit"></i></a>&nbsp; ||| &nbsp;<a href="?delete-data=<?php echo $row['id']; ?>"><i class="fas fa-trash"></i></a></td>

                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

</body>

</html>