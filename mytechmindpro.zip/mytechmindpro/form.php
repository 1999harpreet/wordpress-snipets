<!DOCTYPE HTML>  
<html>
<head>

<style>

</style>
</head>
<body>  



<form action="" method="">
    <label>name</label>
	<input type="text" name="name"><br>
	<label>email</label>
	<input type="email" name="email"><br>
	<label>website</label>
	<input type="text" name="website"><br>
	
	<button type="submit" name="submit"></button>
     

</form>




</body>


  
</html>