$('#staffNeedRange').rangeSlider({
    //settings: true,

    scale: true
}, {
    step: 1,
    values: [50],
    min: 0,
    max: 100
});

$('#staffPresentRange').rangeSlider({
    //    settings: true,
    scale: true
}, {
    step: 1,
    values: [50],
    min: 0,
    max: 100
});



var Whatwouldyouliketodo = document.getElementById('whatWouldYouDo');
var Numberofemployees = document.getElementById('numOfEmployee');
var Officerent = document.getElementById('officeRentArea');
var Adminstaffyearlysalary = document.getElementById('staffIncomAnnually');
var firstSlider = document.querySelector("#staffNeedRange .slider__tip");
var secondSlider = document.querySelector("#staffPresentRange .slider__tip");



/* fixed variables */
var normallockerprice = 250
var smartlockerprice = 450
var upgradelocker = 150
var spacesavedlocker = 0.064
var fulltimeemployelock = 0.83

/*secondaryvariables */
var sourcingnonsmartoperation;
var sourcingsmartoperation;
var lockersaved;
var spacesaved;

/*calculatedvariables */
var savedrent;
var costsavings;
var saassavingannum;

/*primaryvariables */
var capexsavingsmartlocker;
var capexsavingoldsmartlocker;
var opexsaving;



function validateform () {

    var i = 0;
    if (Whatwouldyouliketodo.value == "") {
        document.getElementById('selecterror').innerHTML = "please select";
    } else {
        document.getElementById('selecterror').innerHTML = "";
        i++;
    }
    if (Numberofemployees.value == "") {
        document.getElementById('Employeefield').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('Employeefield').innerHTML = "";
    }
    if (Officerent.value == "") {
        document.getElementById('Rentfield').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('Rentfield').innerHTML = "";
    }
    if (Adminstaffyearlysalary.value == "") {
        document.getElementById('staffIncome').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('staffIncome').innerHTML = "";
    }
    if (firstSlider.getAttribute("data-value") == 0) {
        document.getElementById('firstslidererror').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('firstslidererror').innerHTML = "";
    }
    if (secondSlider.getAttribute("data-value") == 0) {
        document.getElementById('secondslidererror').innerHTML = "please fill this field";
    } else {
        i++;
        document.getElementById('secondslidererror').innerHTML = "";
    }

    if (i == 6) {
        console.log(`What would you like to do value = ${Whatwouldyouliketodo.value} \nNumber of employees Value = ${Numberofemployees.value} \nOffice rent value = ${Officerent.value} \nAdmin staff yearly salary value = ${Adminstaffyearlysalary.value} \nfirst slider value = ${parseInt(firstSlider.getAttribute("data-value"))} \nsecond slider value = ${parseInt(secondSlider.getAttribute("data-value"))}`);
        secondaryvariables();
        calculatedvariables();
        primaryvariables();


        if (Whatwouldyouliketodo.value == "upgrade") {
            oldlocker();
        }
        else if (Whatwouldyouliketodo.value == "buyNew") {
            newlocker();
        }

    }
}



function secondaryvariables () {

    sourcingnonsmartoperation = Numberofemployees.value * parseInt(firstSlider.getAttribute("data-value")) / 100;
    sourcingsmartoperation = sourcingnonsmartoperation * parseInt(secondSlider.getAttribute("data-value")) / 100;
    lockersaved = sourcingnonsmartoperation - sourcingsmartoperation;
    spacesaved = Math.trunc(lockersaved * spacesavedlocker);

    console.log(`sourcing non smart operation = ${sourcingnonsmartoperation} \nsourcing smart operation = ${sourcingsmartoperation} \nlocker saved = ${lockersaved} \nspace saved = ${spacesaved}`);

}


function calculatedvariables () {
    savedrent = lockersaved * spacesavedlocker * Officerent.value;
    costsavings = Math.trunc((Adminstaffyearlysalary.value * sourcingnonsmartoperation * (fulltimeemployelock / 1000)) * 0.94);
    saassavingannum = 18 * sourcingsmartoperation;

    console.log(`saved rent = ${savedrent} \ncost savings = ${costsavings} \nsaas saving annum = ${saassavingannum}`);
}



function primaryvariables () {

    opexsaving = savedrent + costsavings - saassavingannum;
    capexsavingoldsmartlocker = (sourcingnonsmartoperation * normallockerprice) - (sourcingsmartoperation * upgradelocker);
    capexsavingsmartlocker = (sourcingnonsmartoperation * normallockerprice) - (sourcingsmartoperation * smartlockerprice);
    console.log(`opex saving = ${opexsaving}`);
}

function oldlocker () {
    console.log(`capex saving old smartlocker = ${capexsavingoldsmartlocker}`);
}
function newlocker () {
    console.log(`capex saving smart locker = ${capexsavingsmartlocker}`);
}














