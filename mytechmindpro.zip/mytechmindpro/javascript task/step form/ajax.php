<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "covid";
$Name = $_POST['Name'];
$lName = $_POST['lName'];
$Number = $_POST['Number'];
$Mail = $_POST['Mail'];
$Red = $_POST['Red'];
$Rick = $_POST['Rick'];
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    echo "connection failed" . $conn->connect_error;
}
$insert = "INSERT INTO covid_data (Name,lName,Number,Mail,Red,Rick) VALUES ('{$Name}','{$lName}','{$Number}','{$Mail}','{$Red}','{$Rick}')";
// echo $insert;
if ($conn->query($insert) !== TRUE) {
    echo $conn->error;
} else {
    echo "Data Inserted";
}