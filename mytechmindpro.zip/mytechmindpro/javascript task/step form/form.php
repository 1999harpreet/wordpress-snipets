<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <style>
    .container {
        width: 480px;
    }

    main {
        padding: 55px 55px;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        flex-wrap: wrap;
    }

    button {
        background: #1A1818;
        color: #fff;
        display: flex;
        width: 292px;
        font-size: 31px;
        height: 85px;
        align-items: center;
        justify-content: center;
        margin: auto;
    }

    h2 {
        font-size: 35px;
        text-align: center;
    }

    .space-common h2,
    button,
    input {
        margin-bottom: 20px;
    }

    input {

        text-align: center;
    }

    section.employee_compantvisit img {
        cursor: pointer;
    }

    .one img {
        width: 120px;
    }

    .one {
        display: flex;
    }

    button#company_visit img {
        height: 100%;
    }

    button#company_visit {
        background: none;
        border: none;
        height: 100%;
    }

    section.main_section_one.space-common {
        text-align: center;
    }
    </style>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
</head>

<body>
    <div class="container-fluid">
        <div class="container">
            <main style="background-color: #FFCB00;">
                <section class="main_section_one space-common">
                    <h2>Welcome to our COVID-19 contact tracing web portal.</h2>
                    <img src="img.png">
                    <button type="button" id="main_button">Click to continue</button>

                </section>
                <section class="main_section_two pt-5 pb-4 space-common" style="display: none;">
                    <h2>Which of the below are you?</h2>
                    <button type="button" id="employee">I am an employee</button>
                    <button type="button" id="visitor">I am a visitor</button>
                </section>
                <section class="employee_info space-common" style="display: none;">
                    <h2>Please provide us...</h2>
                    <input type="text" class="form-control" id="employee_fname" placeholder="your first name">
                    <span id="errorone"></span>
                    <input type="text" class="form-control" id="employee_lname" placeholder="your last name">
                    <span id="errortwo"></span>
                    <button type="button" id="employee_next" onclick="validateform()">Next</button>
                </section>
                <section class="employee_addinfo space-common" style="display: none;">
                    <h2>Also provide...</h2>
                    <input type="number" class="form-control" id="employee_number" placeholder="your number">
                    <input type="text" class="form-control" id="employee_mail" placeholder="your email">
                    <button type="button" id="employee_addnext" onclick="validateformtwo()">Next</button>
                </section>
                <section class="employee_compantvisit space-common" style="display: none;">
                    <h2>Which company are you visiting?</h2>
                    <button id="company_visit"><img src="company.png"></button>
                </section>
                <section class="employee_companyinfo space-common" style="display: none;">
                    <img src="logo.png" id="company_visit">
                    <h2>What location are you visiting?</h2>
                    <input type="text" class="form-control" id="employee_redlake" placeholder="Red Lake">
                    <h2>Who are you visiting?</h2>
                    <input type="text" class="form-control" id="employee_RickOngaro" placeholder="Rick Ongaro">
                    <button type="button" id="companyinfo" onclick="validateformthree()">Next</button>
                </section>
                <section class="employee_fullvacinated space-common" style="display: none;">

                    <h2>Have you been fully vaccinated?</h2>
                    <button type="button" id="fullvacinatedyes">yes</button>
                    <button type="button" id="fullvacinatedno">No</button>
                </section>
                <section class=" employee_fullvacinatedconfirm space-common" style="display: none;">
                    <div class="one space-common">
                        <img src="img.png">
                        <h2>Have you been fully vaccinated?</h2>
                    </div>
                    <input type="radio" id="chills" value="chills">
                    <label>I DO NOT have a fever or the chills</label><br>
                    <input type="radio" id="cough" value="cough">
                    <label>DO NOT have a new or worsening cough</label><br>
                    <input type="radio" id="swallowing" value="swallowing">
                    <label>I DO NOT have a sore throat, trouble </label><br>
                    <input type="radio" id="nose" value="nose">
                    <label>DO NOT have nasal congestion or a </label><br>
                    <input type="radio" id="smell" value="smell">
                    <label>DO NOT have loss of taste or smell</label><br>
                    <button type="button" id="fullvacinatedyes" onclick="lastsubmit()">Next </button>
                </section>
                <section class="employee_thaku space-common" style="display: none;">
                    <h2>Thank you for providing your information.</h2>
                    <img src="tick.png">
                    <h2>You are cleared to enter our facility.</h2>
                </section>
            </main>
        </div>
    </div>



</body>
<script>
$(document).on('click', 'button', function() {
    $(this).closest(".space-common").hide();
    $(this).closest(".space-common").next(".space-common").show();
});
</script>
<script>
var fieldone = document.getElementById("employee_fname");
var fieldtwo = document.getElementById("employee_lname");
var fieldthree = document.getElementById("employee_number");
var fieldfour = document.getElementById("employee_mail");
var fieldfive = document.getElementById("employee_redlake");
var fieldsix = document.getElementById("employee_RickOngaro");
var chill = document.getElementById("chills");
var cough = document.getElementById("cough");
var swallowing = document.getElementById("swallowing");
var nose = document.getElementById("nose");
var smell = document.getElementById("smell");

// function validateform (e) {
//     if (fieldone.value == "" | fieldtwo.value == "") {
//         document.getElementById("errorone").innerHTML = "please fill this field";
//         e.preventDefault()
//     }
//     else {

//         console.log(`Employee name = ${fieldone.value} \n Employee lastname = ${fieldtwo.value}`)


//     }


//     document.getElementById("employee_addnext").addEventListener('click', function () {
//         console.log(`Employee number = ${fieldthree.value} \n Employee mail = ${fieldfour.value}`)

//     })
//     document.getElementById("companyinfo").addEventListener('click', function () {
//         console.log(`Employee redlake= ${fieldfive.value} \n Employee RickOngaro = ${fieldsix.value}`)

//     })
// }

function validateform() {
    console.log(`Employee name = ${fieldone.value} \n Employee lastname = ${fieldtwo.value}`)
    sessionStorage.setItem('fname', fieldone.value);
    sessionStorage.setItem('lname', fieldtwo.value);

}

function validateformtwo() {
    console.log(`Employee number = ${fieldthree.value} \n Employee mail = ${fieldfour.value}`)
    sessionStorage.setItem('number', fieldthree.value);
    sessionStorage.setItem('mail', fieldfour.value);
}

function validateformthree() {
    console.log(`Employee redlake= ${fieldfive.value} \n Employee RickOngaro = ${fieldsix.value}`)
    sessionStorage.setItem('redlake', fieldfive.value);
    sessionStorage.setItem('RickOngaro', fieldsix.value);
}

function lastsubmit() {

    console.log(
        `chill = ${chills.getAttribute("data-value")} \n cough = ${cough.getAttribute("data-value")} \n swallowing = ${swallowing.getAttribute("data-value")} \n nose = ${nose.getAttribute("data-value")} \n smell = ${smell.getAttribute("data-value")} `
    )



    let name = sessionStorage.getItem('fname');
    let last = sessionStorage.getItem('lname');
    let number = sessionStorage.getItem('number');
    let mail = sessionStorage.getItem('mail');
    let redlake = sessionStorage.getItem('redlake');
    let RickOngaro = sessionStorage.getItem('RickOngaro');
    $.ajax({
        url: 'ajax.php',
        type: 'post',
        data: {
            'Name': name,
            'lName': last,
            'Number': number,
            'Mail': mail,
            'Red': redlake,
            'Rick': RickOngaro,

        },
        success: function(temp) {

            alert(temp);
        },
        error: function() {
            alert('There was some error performing the AJAX call!');
        }
    });
}
</script>





</html>