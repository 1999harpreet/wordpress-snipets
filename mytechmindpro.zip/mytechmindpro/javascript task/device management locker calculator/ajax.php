<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "elocker_calc";
$Asset = $_POST['Asset'];
$Number_of_Assets = $_POST['Number_of_Assets'];
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    echo "connection failed" . $conn->connect_error;
}
$insert = "INSERT INTO elocker_calc_data (Asset,Number_of_Assets) VALUES ('{$Asset}','{$Number_of_Assets}')";
// echo $insert;
if ($conn->query($insert) !== TRUE) {
    echo $conn->error;
} else {
    echo "Data Inserted";
}
