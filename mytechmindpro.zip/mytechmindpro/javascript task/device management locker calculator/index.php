<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <div class="ks_roi_calc">
            <div class="row">
                <div class="col-lg-7 col-md-7 col-sm-10 col-12 mx-auto">
                    <div class="roi-calc-form-heading">
                        <h6>Device Management Locker</h6>
                        <h2>Smart Office Locker</h2>
                        <p>Enter your informatoin in the calculator to outline the a financial return on investment for
                            your
                            office locker project, showing how the system pays for itself</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- <form action="" method="post" class="ks-roi-form-class"> -->
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Type of Asset</label>
                    <select class="form-select forErr" id="typeasset">
                        <option value="">Select</option>
                        <option value="gun">RF Gun</option>
                        <option value="scan">Scanner</option>
                        <option value="hmt">HHT/AMT</option>
                        <option value="ipet">iPad/Tablet</option>
                        <option value="cogs">Controlled Drugs</option>
                        <option value="radio">Radio</option>
                        <option value="lap">Laptop</option>
                    </select>
                    <span id="selecterror"></span>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Number of Assets</label>
                    <div class="position-relative">
                        <input type="text" class="form-control" value="100" id="numOfassets">
                    </div>
                    <span id="assetfield"></span>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Cost Per Asset</label>
                    <div class="position-relative">
                        <input type="number" class="form-control" value="2000" id="costofasset" min="0">
                    </div>
                    <span id="costaasetfield"></span>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Shifts Per day</label>
                    <select class="form-select forErr" id="ShiftsPerday">
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                    </select>
                    <span id="shiftselecterror"></span>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Number of Users</label>
                    <div class="position-relative">
                        <input type="number" class="form-control forErr" value="300" id="NumberofUsers" min="0">
                    </div>
                    <span id="usersfield"></span>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                <div class="mt-2">
                    <label class="form-label">Yearly Salary Per User</label>
                    <div class="position-relative ks_input">
                        <input type="number" class="form-control forErr" value="22000" id="YearlySalaryPerUser" min="0">
                    </div>
                    <span id="yearlysalary"></span>
                </div>
            </div>

            <div class="col-lg-12 col-md-6 col-sm-12 col-12">
                <div class="hs_bar mb_0">
                    <label class="form-label">What is your % of asset loss Per Year</label>

                    <!-- Range Slider created by rangeslider.js -->
                    <div id="staffNeedRange"></div>
                    <span id="assetlosserror"></span>
                </div>
            </div>

            <div class="col-lg-12 col-md-6 col-sm-12 col-12">
                <div class="hs_bar">
                    <label class="form-label">What is your % of asset damage Per Year</label>

                    <!-- Range Slider created by rangeslider.js -->
                    <div id="staffPresentRange"></div>
                    <span id="damageerror"></span>
                </div>
            </div>
        </div>

        <div class="row d-flex justify-content-center">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="hs_form button">
                    <input type="submit" value="submit" id="" onclick="validateform()">
                </div>
            </div>


        </div>
        <!-- </form> -->

        <p id="output"></p>
    </div>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="rangeslider.js"></script>
<!-- <script src="function.js"></script> -->
<?php 
 include('function.php');
?>

</html>